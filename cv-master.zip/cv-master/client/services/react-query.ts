import { QueryClient } from 'react-query';

const queryClient = new QueryClient();

export default queryClient;
