import React from 'react';

export type SidebarSection = {
  id: string;
  icon: React.ReactElement;
  component: React.ReactElement;
};
