/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://rxresu.me',
  changefreq: 'monthly',
  generateRobotsTxt: true,
};
