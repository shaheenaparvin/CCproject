const isBrowser = typeof window !== 'undefined';

export default isBrowser;
