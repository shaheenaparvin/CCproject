// Date Formats
export const FILENAME_TIMESTAMP = 'DDMMYYYYHHmmss';
