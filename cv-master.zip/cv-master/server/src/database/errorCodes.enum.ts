export enum PostgresErrorCode {
  UniqueViolation = '23505',
}
