export type DateRange = {
  start?: string;
  end?: string;
};
