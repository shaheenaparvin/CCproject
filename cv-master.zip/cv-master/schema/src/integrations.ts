export type Integration = 'linkedin' | 'json-resume' | 'reactive-resume' | 'reactive-resume-v2';
